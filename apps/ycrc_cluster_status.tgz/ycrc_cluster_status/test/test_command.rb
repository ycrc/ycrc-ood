require 'minitest_helper'
require 'command'

class TestCommand < Minitest::Test

  def test_command_output_parsing
    output = <<-EOF

This script shows information about your quotas on the current gpfs filesystem.
If you plan to poll this sort of information extensively, please contact us
for help at hpc@yale.edu

## Usage Details for hpcprog (as of Oct 09 2019 04:00)
Fileset       User  Usage (GB) File Count   
------------- ----- ---------- -------------
project       ahs3          81        31,433
project       cag94          0             1
project       kln26        356       520,587
project       njc2           0             1
project       pl543         16       221,164
project       sw464         34       310,252
project       tl397        365       488,015
----
scratch60     ahs3           0           205
scratch60     cag94          0             1
scratch60     kln26         39       707,774
scratch60     njc2           0             1
scratch60     pl543          0             1
scratch60     sw464          0             1
scratch60     tl397      13696        37,195

## Quota Summary for hpcprog (as of right now)
Fileset       Type    Usage (GB)   Quota (GB)  File Count    File Limit    Backup    Purged   
------------- ------- ------------ ----------- ------------- ------------- --------- ---------
home.grace    USR                0         100        11,237       200,000 Yes        No        
project       GRP              637        6144     1,530,349     5,000,000 No         No        
scratch60     GRP             6855       20480       724,922     5,000,000 No         60 days

EOF
    processes = Command.new.parse(output)

    assert_equal 1, processes.count

    p = processes.first

    assert_equal "efranz", p.user
    assert_equal "462148", p.vsz
    assert_equal "28128", p.rss
    assert_equal "0:00", p.time
    assert_equal "Passenger RackApp: /users/PZS0562/efranz/awesim/dev/ood-example-ps", p.command
  end
end
