require 'erubi'
require './command'
require "/share/support/public/ood/ruby/hostspecs.rb"

$hostname = getHostSpecs()[:host]

set :erb, :escape_html => true

if development?
  require 'sinatra/reloader'
  also_reload './command.rb'
end

helpers do
  def dashboard_title
    $hostname+" OnDemand"
  end

  def dashboard_url
    "/pun/sys/dashboard/"
  end

  def title
    "Cluster Node Status"
  end
end

# Define a route at the root '/' of the app.
get '/' do
  @command = Command.new
  @gpu_public_node_status, @cpu_public_node_status, 
  @gpu_private_node_status, @cpu_private_node_status,
  @error1, @error2, @error3, @error4 = @command.exec

  # Render the view
  erb :index
end
